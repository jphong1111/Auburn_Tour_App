package com.example.myfirstapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    //https://imgbin.com/png/9c1CmQ4scopy Auburn Logo Resource


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //How Button1 works
        Button Sub1_Button = (Button) findViewById(R.id.SubButton1);
        Sub1_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Move to next Sub1Activity (Screen Transition)
            Intent move_main_sub1 = new Intent(MainActivity.this,sub1_Activity.class);
            startActivity(move_main_sub1);
            }
        });


        //How Button3 works
        Button Sub3_Button = (Button) findViewById(R.id.SubButton3);
        Sub3_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Move to next Sub3Activity (Screen Transition)
                Intent move_main_sub3 = new Intent(MainActivity.this,sub3_Activity.class);
                startActivity(move_main_sub3);
            }
        });


        //How Button works
        Button Sub4_Button = (Button) findViewById(R.id.SubButton4);
        Sub4_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Move to next Sub43Activity (Screen Transition)
                Intent move_main_sub4 = new Intent(MainActivity.this,sub4_Activity.class);
                startActivity(move_main_sub4);
            }
        });


    }
}
